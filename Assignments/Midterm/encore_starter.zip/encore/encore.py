"""
Encore -- a ListenBrainz music agent that remembers.   (CSCI 391 midterm starter)

    python encore.py <online|offline>             # interactive session
    python encore.py <online|offline> --forget    # delete every memory for ENCORE_USER_ID

Copy chat() and model_for() from your Lab 3 agent and your router from Lab 4.
"""

import json
import os
import random
import time
from dataclasses import asdict, dataclass
from typing import Any, Optional

import requests
from dotenv import load_dotenv

load_dotenv()

LB_API = "https://api.listenbrainz.org/1"
MB_API = "https://musicbrainz.org/ws/2"
LB_TOKEN = os.getenv("LISTENBRAINZ_TOKEN")        # never log or store this
LB_USER = os.getenv("LISTENBRAINZ_USER")
ENCORE_USER_ID = os.getenv("ENCORE_USER_ID", LB_USER)  # deletion key for all memory
USER_AGENT = f"Encore-CSCI391/0.1 ( {os.getenv('CONTACT_EMAIL', 'you@umontana.edu')} )"

MAX_STEPS = 12          # bounded loop (Lab 2)
READ_TIMEOUT_S = 5
WRITE_TIMEOUT_S = 15
SLOW_READ_TIMEOUT_S = 15  # override for reads measured to be slow (ListenBrainz listens)
MB_MIN_INTERVAL_S = 1.5  # MusicBrainz allows about 1 request/second per IP; leave headroom

_last_mb_call = 0.0
_lb_wait_until = 0.0


@dataclass
class ToolResult:                      # same contract as the Chapter 6 examples
    success: bool
    data: Optional[Any]
    error: Optional[str]
    error_category: Optional[str]      # "transient" | "input" | "resource" | "fatal"

    def to_json(self) -> str:
        return json.dumps(asdict(self))


def ok(data: Any) -> ToolResult:
    return ToolResult(True, data, None, None)


def fail(category: str, message: str) -> ToolResult:
    return ToolResult(False, None, message, category)


def classify_status(status: int) -> str:
    if status == 0 or status == 429 or status >= 500:
        return "transient"
    if status in (401, 403):
        return "fatal"
    if status == 404:
        return "resource"
    return "input"


def http(method: str, url: str, *, params=None, body=None, auth=False, timeout=READ_TIMEOUT_S):
    """One polite request. Returns (status, json_or_text, headers). Status 0 = no response."""
    global _last_mb_call, _lb_wait_until
    if url.startswith(MB_API):
        wait = _last_mb_call + MB_MIN_INTERVAL_S - time.monotonic()
        if wait > 0:
            time.sleep(wait)
        _last_mb_call = time.monotonic()
        params = {**(params or {}), "fmt": "json"}
    elif url.startswith(LB_API):
        wait = _lb_wait_until - time.monotonic()
        if wait > 0:                                  # honor the server's rate-limit headers
            time.sleep(wait)
    headers = {"User-Agent": USER_AGENT}
    if auth:
        headers["Authorization"] = f"Token {LB_TOKEN}"
    try:
        r = requests.request(method, url, params=params, json=body, headers=headers, timeout=timeout)
    except requests.RequestException as exc:
        return 0, f"{type(exc).__name__}", {}
    if url.startswith(LB_API) and r.headers.get("X-RateLimit-Remaining") == "0":
        _lb_wait_until = time.monotonic() + float(r.headers.get("X-RateLimit-Reset-In", "1"))
    try:
        return r.status_code, r.json(), r.headers
    except ValueError:
        return r.status_code, r.text, r.headers


# ---------------------------------------------------------------- worked examples

def get_recent_listens(count: int = 25) -> str:
    if not 1 <= count <= 100:
        return fail("input", f"count must be between 1 and 100; got {count}.").to_json()
    status, body, _ = http("GET", f"{LB_API}/user/{LB_USER}/listens", params={"count": count},
                           timeout=SLOW_READ_TIMEOUT_S)
    if status != 200:
        return fail(classify_status(status), f"ListenBrainz listens request failed (HTTP {status}).").to_json()
    listens = []
    for item in body["payload"]["listens"]:
        meta = item["track_metadata"]
        listens.append({
            "listened_at": item["listened_at"],
            "artist": meta.get("artist_name"),
            "track": meta.get("track_name"),
            "recording_mbid": (meta.get("mbid_mapping") or {}).get("recording_mbid"),
        })
    return ok({"listens": listens}).to_json()


def search_recordings(title: str, artist: str = "", limit: int = 5) -> str:
    if not title.strip():
        return fail("input", "title must not be empty.").to_json()
    query = f'recording:"{title}"' + (f' AND artist:"{artist}"' if artist else "")
    status, body, _ = http("GET", f"{MB_API}/recording", params={"query": query, "limit": limit})
    if status != 200:
        return fail(classify_status(status), f"MusicBrainz search failed (HTTP {status}).").to_json()
    hits = [{
        "recording_mbid": r["id"],
        "title": r["title"],
        "artist": "".join(c["name"] + c.get("joinphrase", "") for c in r.get("artist-credit", [])),
        "length_s": (r.get("length") or 0) // 1000,
        "first_release": r.get("first-release-date"),
    } for r in body.get("recordings", [])]
    if not hits:
        return fail("resource", f"No MusicBrainz recording matches '{title}'"
                                f"{' by ' + artist if artist else ''}.").to_json()
    return ok({"recordings": hits}).to_json()


# TODO 1: implement the remaining required tools in Part 3 (same ToolResult contract)
# TODO 2: write a JSON schema for every tool: descriptions say when NOT to use it,
#         bounded values are enums, write tools state their side effects (Part 3)

TOOLS = {
    "get_recent_listens": get_recent_listens,
    "search_recordings": search_recordings,
}


def backoff_delays(attempts: int = 4, base: float = 1.0, cap: float = 30.0):
    """Exponential backoff with full jitter. The LOOP retries transient errors, never the model."""
    return [random.uniform(0, min(cap, base * 2 ** i)) for i in range(attempts)]


def run_session(mode: str) -> None:
    # TODO 3: session start -- load procedural memory (prompts/system_v1.md) and hot state,
    #         retrieve episodic memories for the first message, and front-load them (Part 5)
    # TODO 4: bounded ReAct loop -- route tools (Lab 4), reinject constraints every call
    #         (Lab 3), retry transient errors with backoff_delays(), gate writes behind
    #         approval, compress working memory past its budget, log every step (Part 6)
    # TODO 5: end the loop only through final_answer or a termination status (Part 4)
    # TODO 6: session end -- structured summary, quality check, dedup, store (Part 5)
    raise NotImplementedError


def forget_user(user_id: str) -> None:
    # TODO 7: delete every stored item for user_id from EVERY store and print the counts
    raise NotImplementedError
